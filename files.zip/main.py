"""
DNA LSTM Generator — FastAPI Backend
=====================================
Developed by Nitin Mall

Run locally:
    pip install fastapi uvicorn tensorflow pandas numpy scikit-learn python-multipart
    uvicorn main:app --reload --port 8000

The frontend talks to this server. It:
  1. Accepts a CSV upload
  2. Trains the LSTM on YOUR data (streams epoch-by-epoch progress)
  3. Generates sequences using the trained model
  4. Caches the model in memory so re-generation is instant
"""

import io
import os
import json
import random
import asyncio
import warnings
import threading
import numpy as np
import pandas as pd
from queue import Queue
from typing import Optional

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
warnings.filterwarnings("ignore")

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Embedding, Dropout
from tensorflow.keras.callbacks import Callback, EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split

app = FastAPI(title="DNA LSTM Generator — Nitin Mall")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # tighten in production if needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── In-memory model cache ─────────────────────────────────────
class ModelStore:
    def __init__(self):
        self.model      = None
        self.char2idx   = None
        self.idx2char   = None
        self.config     = None
        self.sequences  = []
        self.trained    = False

store = ModelStore()

# ── Pydantic request models ───────────────────────────────────
class TrainConfig(BaseModel):
    sequence_col: str   = "sequence"
    min_seq_len:  int   = 50
    window_size:  int   = 50
    step:         int   = 5
    max_sequences:int   = 50000
    embedding_dim:int   = 8
    lstm_units_1: int   = 128
    lstm_units_2: int   = 64
    dropout_rate: float = 0.3
    batch_size:   int   = 256
    epochs:       int   = 20
    learning_rate:float = 0.001
    val_split:    float = 0.1
    patience:     int   = 5

class GenerateRequest(BaseModel):
    num_sequences: int   = 3
    gen_length:    int   = 100
    temperature:   float = 1.0
    seed:          Optional[str] = None

# ── Helpers ───────────────────────────────────────────────────
def clean_sequences(df: pd.DataFrame, col: str, min_len: int) -> list[str]:
    if col not in df.columns:
        available = ", ".join(df.columns.tolist())
        raise ValueError(f'Column "{col}" not found. Available: {available}')
    seqs = (
        df[col].dropna().astype(str)
        .str.strip().str.upper()
        .apply(lambda s: "".join(c for c in s if c in "ACGT"))
        .pipe(lambda s: s[s.str.len() >= min_len])
        .tolist()
    )
    if not seqs:
        raise ValueError("No valid DNA sequences found after cleaning.")
    return seqs

def build_vocab():
    chars = sorted("ACGT")
    char2idx = {c: i for i, c in enumerate(chars)}
    idx2char  = {i: c for c, i in char2idx.items()}
    return char2idx, idx2char

def make_windows(sequences, char2idx, window, step, max_samples):
    X_list, y_list = [], []
    for seq in sequences:
        enc = [char2idx[c] for c in seq if c in char2idx]
        for start in range(0, len(enc) - window, step):
            X_list.append(enc[start: start + window])
            y_list.append(enc[start + window])
        if len(X_list) >= max_samples:
            break
    pairs = list(zip(X_list, y_list))
    random.shuffle(pairs)
    pairs = pairs[:max_samples]
    X_list, y_list = zip(*pairs)
    return np.array(X_list, dtype=np.int32), np.array(y_list, dtype=np.int32)

def build_model(cfg: TrainConfig, vocab_size: int) -> tf.keras.Model:
    model = Sequential([
        Embedding(vocab_size, cfg.embedding_dim, input_length=cfg.window_size, name="embed"),
        LSTM(cfg.lstm_units_1, return_sequences=True, name="lstm_1"),
        Dropout(cfg.dropout_rate, name="drop_1"),
        LSTM(cfg.lstm_units_2, name="lstm_2"),
        Dropout(cfg.dropout_rate, name="drop_2"),
        Dense(vocab_size, activation="softmax", name="output"),
    ], name="DNA_LSTM")
    model.compile(
        optimizer=Adam(lr=cfg.learning_rate),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model

def sample_temperature(probs, temperature):
    probs = np.asarray(probs, dtype=np.float64)
    probs = np.log(probs + 1e-10) / temperature
    probs = np.exp(probs - probs.max())
    probs /= probs.sum()
    return int(np.random.choice(len(probs), p=probs))

def generate_one(model, seed_enc, char2idx, idx2char, gen_length, temperature):
    window = len(seed_enc)
    current = list(seed_enc)
    out = []
    for _ in range(gen_length):
        x = np.array(current[-window:], dtype=np.int32)[np.newaxis, :]
        probs = model.predict(x, verbose=0)[0]
        nxt = sample_temperature(probs, temperature)
        out.append(nxt)
        current.append(nxt)
    return "".join(idx2char[i] for i in out)

# ── SSE streaming callback ────────────────────────────────────
class StreamCallback(Callback):
    def __init__(self, q: Queue, total_epochs: int):
        super().__init__()
        self.q = q
        self.total = total_epochs

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        self.q.put({
            "type":     "epoch",
            "epoch":    epoch + 1,
            "total":    self.total,
            "loss":     round(float(logs.get("loss", 0)), 4),
            "val_loss": round(float(logs.get("val_loss", 0)), 4),
            "acc":      round(float(logs.get("accuracy", 0)) * 100, 2),
            "val_acc":  round(float(logs.get("val_accuracy", 0)) * 100, 2),
        })

    def on_train_end(self, logs=None):
        self.q.put({"type": "train_end"})

# ── Routes ────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "DNA LSTM Backend running", "developer": "Nitin Mall"}

@app.get("/status")
def status():
    return {
        "trained":    store.trained,
        "sequences":  len(store.sequences),
        "config":     store.config,
    }

@app.post("/upload-csv")
async def upload_csv(file: UploadFile = File(...), sequence_col: str = "sequence", min_seq_len: int = 50):
    """Parse and preview a CSV file — no training yet."""
    content = await file.read()
    try:
        raw = content.decode("utf-8-sig")          # handles UTF-8 BOM
        df = pd.read_csv(io.StringIO(raw))
        seqs = clean_sequences(df, sequence_col, min_seq_len)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    lengths = [len(s) for s in seqs]
    return {
        "rows":     len(seqs),
        "columns":  df.columns.tolist(),
        "avg_len":  round(sum(lengths) / len(lengths)),
        "min_len":  min(lengths),
        "max_len":  max(lengths),
        "sample":   seqs[:3],
    }

@app.post("/train")
async def train(file: UploadFile = File(...), config: str = "{}"):
    """
    Upload CSV + config JSON → train LSTM → stream SSE progress.
    Frontend connects with EventSource('/train') after a POST.
    We use a thread + Queue to bridge sync Keras training with async SSE.
    """
    content = await file.read()
    try:
        cfg_dict = json.loads(config)
        cfg = TrainConfig(**cfg_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Bad config: {e}")

    try:
        raw = content.decode("utf-8-sig")
        df = pd.read_csv(io.StringIO(raw))
        sequences = clean_sequences(df, cfg.sequence_col, cfg.min_seq_len)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    q: Queue = Queue()

    def run_training():
        try:
            q.put({"type": "log", "msg": f"Loaded {len(sequences):,} sequences."})
            char2idx, idx2char = build_vocab()
            vocab_size = len(char2idx)

            q.put({"type": "log", "msg": "Building sliding-window dataset..."})
            X, y = make_windows(sequences, char2idx, cfg.window_size, cfg.step, cfg.max_sequences)
            q.put({"type": "log", "msg": f"Dataset: {len(X):,} samples  |  vocab: {vocab_size} tokens"})

            X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=cfg.val_split, random_state=42, stratify=y)
            q.put({"type": "log", "msg": f"Train: {len(X_train):,}  Val: {len(X_val):,}"})

            model = build_model(cfg, vocab_size)
            q.put({"type": "log", "msg": f"Model: Embed({vocab_size}→{cfg.embedding_dim}) → LSTM({cfg.lstm_units_1}) → LSTM({cfg.lstm_units_2}) → Dense({vocab_size})"})
            q.put({"type": "log", "msg": f"Starting training for up to {cfg.epochs} epochs..."})

            callbacks = [
                StreamCallback(q, cfg.epochs),
                EarlyStopping(monitor="val_loss", patience=cfg.patience, restore_best_weights=True, verbose=0),
                ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=max(2, cfg.patience // 2), min_lr=1e-6, verbose=0),
            ]

            model.fit(
                X_train, y_train,
                validation_data=(X_val, y_val),
                batch_size=cfg.batch_size,
                epochs=cfg.epochs,
                callbacks=callbacks,
                verbose=0,
            )

            # Cache trained model
            store.model     = model
            store.char2idx  = char2idx
            store.idx2char  = idx2char
            store.config    = cfg.dict()
            store.sequences = sequences
            store.trained   = True
            q.put({"type": "log", "msg": "Training complete. Model cached."})
            q.put({"type": "done"})

        except Exception as e:
            q.put({"type": "error", "msg": str(e)})

    thread = threading.Thread(target=run_training, daemon=True)
    thread.start()

    def event_stream():
        while True:
            item = q.get()
            yield f"data: {json.dumps(item)}\n\n"
            if item["type"] in ("done", "error"):
                break

    return StreamingResponse(event_stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/generate")
def generate(req: GenerateRequest):
    """Generate sequences from the cached trained model."""
    if not store.trained or store.model is None:
        raise HTTPException(status_code=400, detail="No trained model found. Please train first.")

    window = store.config["window_size"]
    char2idx = store.char2idx
    idx2char = store.idx2char

    # Choose seed
    if req.seed and all(c in "ACGT" for c in req.seed.upper()):
        seed_str = req.seed.upper()
    elif store.sequences:
        src = random.choice(store.sequences)
        start = random.randint(0, max(0, len(src) - window))
        seed_str = src[start: start + window]
    else:
        seed_str = "ATGCCCCAACTAAATACT"

    seed_enc = [char2idx[c] for c in seed_str if c in char2idx]
    if len(seed_enc) < 5:
        raise HTTPException(status_code=400, detail="Seed too short or invalid characters.")

    results = []
    for i in range(req.num_sequences):
        seq = generate_one(store.model, seed_enc, char2idx, idx2char, req.gen_length, req.temperature)
        gc = round((seq.count("G") + seq.count("C")) / max(len(seq), 1) * 100, 1)
        results.append({"id": i + 1, "sequence": seq, "length": len(seq), "gc_percent": gc})

    return {"sequences": results, "seed_used": seed_str, "model_config": store.config}


@app.delete("/model")
def clear_model():
    """Clear the cached model to free memory."""
    store.model = None
    store.trained = False
    store.sequences = []
    return {"cleared": True}
